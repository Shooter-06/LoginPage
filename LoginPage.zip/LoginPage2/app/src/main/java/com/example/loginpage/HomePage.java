package com.example.loginpage;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.media.Image;
import android.os.Bundle;
import android.view.View;
import android.widget.GridLayout;
import android.widget.ImageView;

public class HomePage extends AppCompatActivity {

    ImageView pep, cheese, mashrooms,pineapple;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_page);

        pep =findViewById(R.id.pep);
        cheese =findViewById(R.id.cheese);
        mashrooms =findViewById(R.id.mashroom);
        pineapple =findViewById(R.id.pineapple);

        pep.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent p = new Intent(HomePage.this, PepperoniPizza.class);
                startActivity(p);
            }
        });

        cheese.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent c = new Intent(HomePage.this, CheesePizza.class);
                startActivity(c);
            }
        });

        mashrooms.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent m = new Intent(HomePage.this, Mashrooms.class);
                startActivity(m);
            }
        });

        pineapple.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent p = new Intent(HomePage.this, PineApplePizza.class);
                startActivity(p);
            }
        });
    }
}