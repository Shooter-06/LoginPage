package com.example.loginpage;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class PepperoniPizza extends AppCompatActivity {

    Button add, minus;
    TextView tenCadCounter;

    EditText message;
    int tenCadCount =10;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pepperoni_pizza);

        tenCadCounter =findViewById(R.id.textView14);
        add =findViewById(R.id.button9);
        minus =findViewById(R.id.button10);

        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                tenCadCount =tenCadCount+2;
            }
        });

        minus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(tenCadCount ==10){
                    tenCadCount =10;
                }else{
                    tenCadCount =tenCadCount-2;
                }
                tenCadCounter.setText(String.valueOf(tenCadCounter));
            }
        });
    }
}